import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-packing-panel',
  templateUrl: './packing-panel.component.html',
  styleUrls: ['./packing-panel.component.scss']
})
export class PackingPanelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
