export const CONFIG = {
    "api_service_uri": "http://localhost:8888"
}